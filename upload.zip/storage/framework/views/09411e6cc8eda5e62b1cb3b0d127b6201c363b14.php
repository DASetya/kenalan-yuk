<?php $__env->startSection('scripts'); ?>
<script>
    let ctx = document.getElementById('myChart');
    let myChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($labels); ?>,
            datasets: [{
                label: 'Tingkat Kebahagiaan',
                data: <?php echo e(json_encode($data)); ?>,
                backgroundColor: [
                    'rgba(69, 170, 242, 0.2)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
    </script>
<?php $__env->stopSection(); ?>

<div>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold leading-tight">
            Mood
            <a href="#" class="text-2xl"><i class="far fa-question-circle"></i></a>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container mx-auto sm:px-6 lg:px-8">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mood.create-mood', [])->html();
} elseif ($_instance->childHasBeenRendered('h2oaJfW')) {
    $componentId = $_instance->getRenderedChildComponentId('h2oaJfW');
    $componentTag = $_instance->getRenderedChildComponentTagName('h2oaJfW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('h2oaJfW');
} else {
    $response = \Livewire\Livewire::mount('mood.create-mood', []);
    $html = $response->html();
    $_instance->logRenderedChild('h2oaJfW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
            <canvas id="myChart" width="400" height="250"></canvas>
        </div>
    </div>
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/mood/index.blade.php ENDPATH**/ ?>