<div>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold leading-tight">
            Daftar Psikolog
            <a href="#" class="text-2xl"><i class="far fa-question-circle"></i></a>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container mx-auto sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl grid grid-cols-3 gap-5 overflow-hidden shadow-md sm:rounded-lg my-5 p-3">
                <div class="col-start-2 text-center my-auto">
                    <h2 class="text-primary font-bold">Psikolog Di Sekitar</h2>
                </div>
            </div>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    wire:click="$emitTo('psychologist.detail', 'showModal', <?php echo e($datum->id); ?>)" 
                    class="bg-white rounded-2xl cursor-pointer grid grid-cols-3 gap-5 overflow-hidden shadow-md sm:rounded-lg my-5 p-3"
                >
                    <div class="mx-auto">
                        <img class="w-52 h-32 object-cover" src="<?php echo e($datum->image_path); ?>" alt="<?php echo e($datum->image); ?>">
                    </div>
                    <div class="col-span-2 my-auto">
                        <h3 class="text-xl font-bold"><?php echo e($datum->name); ?></h3>
                        <span><?php echo e(strip_tags($datum->description)); ?></span>
                    </div>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('psychologist.detail', ['psychologistId' => $datum->id])->html();
} elseif ($_instance->childHasBeenRendered('detailPsychologist-' . $datum->id)) {
    $componentId = $_instance->getRenderedChildComponentId('detailPsychologist-' . $datum->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('detailPsychologist-' . $datum->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('detailPsychologist-' . $datum->id);
} else {
    $response = \Livewire\Livewire::mount('psychologist.detail', ['psychologistId' => $datum->id]);
    $html = $response->html();
    $_instance->logRenderedChild('detailPsychologist-' . $datum->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($data->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/psychologist/index.blade.php ENDPATH**/ ?>