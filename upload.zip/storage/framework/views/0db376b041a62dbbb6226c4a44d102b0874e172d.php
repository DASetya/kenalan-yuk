<div>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold leading-tight">
            Syukur
            <a href="#" class="text-2xl"><i class="far fa-question-circle"></i></a>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container mx-auto sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl grid grid-cols-3 gap-5 overflow-hidden shadow-md sm:rounded-lg my-5 p-3">
                <div class="col-start-2 text-center my-auto">
                    <h2 class="text-primary font-bold">
                        Syukur
                        <button wire:click="$toggle('showModalAddSyukur')" class="float-right"><i class="fas fa-plus"></i></button>
                    </h2>
                </div>
                
                <div>
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.modal','data' => ['id' => 'modalAddSyukur','maxWidth' => 500,'wire:model' => 'showModalAddSyukur']]); ?>
<?php $component->withName('jet-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('modalAddSyukur'),'maxWidth' => 500,'wire:model' => 'showModalAddSyukur']); ?>
                        <form wire:submit.prevent="store">
                            <div class="px-6 py-4">
                                <div class="text-lg text-bold">
                                    Tambah Gratitude Journal
                                </div>
                        
                                <div class="mt-4">
                                    <div class="grid">
                                        <div class="mx-auto">
                                            <!-- Profile Photo File Input -->
                                            <input type="file" class="hidden" name="image"
                                                        x-ref="photo"
                                                        wire:model="image"
                                            />
                            
                                            <!-- Current Profile Photo -->
                                            <div class="grid mt-2">
                                                <img src="<?php echo e($currentImage); ?>" class="rounded-full h-20 w-20 object-cover mx-auto">
                                            </div>
                                            
                                            <div class="grid mt-2 mb-5">
                                                <button class="button mx-auto" type="button" x-on:click.prevent="$refs.photo.click()">
                                                    Upload Gambar
                                                </button>
                                                 <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'image','class' => 'mx-auto']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'image','class' => 'mx-auto']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            </div>
                                        </div>
                                        
                                        <textarea wire:model="story" rows="5" placeholder="Ada apa dengan hari ini ?" class="border p-3 shadow-sm w-2/3 mx-auto rounded-lg"></textarea>
                                         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'story','class' => 'mx-auto']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'story','class' => 'mx-auto']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                    </div>
                                </div>
                            </div>
                        
                            <div class="px-6 py-4 bg-gray-100 text-right">
                                <button type="submit" class="button button-success mr-3">Tambah <i class="fas fa-plus"></i></button>
                                <button wire:click="$toggle('showModalAddSyukur')" class="button" type="button">Tutup <i class="fas fa-times"></i></button>
                            </div>
                        </form>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                </div>
            </div>
            <?php $__currentLoopData = $syukurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $syukur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    wire:click="$emitTo('syukur.edit', 'showModal', <?php echo e($syukur->id); ?>)" 
                    class="bg-white rounded-2xl cursor-pointer grid grid-cols-3 gap-5 overflow-hidden shadow-md sm:rounded-lg my-5 p-3"
                >
                    <div class="mx-auto">
                        <img class="w-52 h-32 object-cover" src="<?php echo e($syukur->image_path); ?>" alt="<?php echo e($syukur->image); ?>">
                    </div>
                    <div class="col-span-2 text-center my-auto">
                        <span><?php echo e($syukur->story); ?></span>
                    </div>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('syukur.edit', ['syukurId' => $syukur->id])->html();
} elseif ($_instance->childHasBeenRendered('listSyukur-' . $syukur->id)) {
    $componentId = $_instance->getRenderedChildComponentId('listSyukur-' . $syukur->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('listSyukur-' . $syukur->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('listSyukur-' . $syukur->id);
} else {
    $response = \Livewire\Livewire::mount('syukur.edit', ['syukurId' => $syukur->id]);
    $html = $response->html();
    $_instance->logRenderedChild('listSyukur-' . $syukur->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($syukurs->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/syukur/index.blade.php ENDPATH**/ ?>