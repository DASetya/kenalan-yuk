<div>
    <?php echo e($debug); ?> <br>
    <?php echo e($data); ?>


    
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/mood/list-mood.blade.php ENDPATH**/ ?>