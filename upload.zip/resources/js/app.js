require('./bootstrap')
window.Chart = require('chart.js')
