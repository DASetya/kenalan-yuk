<?php

namespace App\Http\Livewire\Partials;

use Livewire\Component;

class NavigationFooter extends Component
{
    public function render()
    {
        return view('livewire.partials.navigation-footer');
    }
}
