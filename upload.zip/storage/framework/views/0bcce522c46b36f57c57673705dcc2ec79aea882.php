<div>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.modal','data' => ['maxWidth' => 500,'wire:model' => 'showModalDetail']]); ?>
<?php $component->withName('jet-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['maxWidth' => 500,'wire:model' => 'showModalDetail']); ?>
        <div class="px-6 py-4">
            <div class="text-lg text-bold">
                Detail Psikolog
            </div>
    
            <div class="mt-4">
                <div class="grid">
                    <div class="mx-auto">
                        <h3 class="text-lg font-bold text-center"><?php echo e($datum->name); ?></h3>
                        <img class="w-52 h-32 object-cover my-2 mx-auto" src="<?php echo e($datum->image_path); ?>" alt="<?php echo e($datum->image); ?>">
                        <div class="px-3">
                            <?php echo $datum->description; ?>

                        </div>
                        <div class="my-2"></div>
                        <?php echo $datum->gmap; ?>

                    </div>
                </div>
            </div>
        </div>
    
        <div class="grid px-6 py-4 bg-gray-100">
            <div class="text-right">
                <button wire:click="$toggle('showModalDetail')" class="button" type="button">Tutup <i class="fas fa-times"></i></button>
            </div>
        </div>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/psychologist/detail.blade.php ENDPATH**/ ?>