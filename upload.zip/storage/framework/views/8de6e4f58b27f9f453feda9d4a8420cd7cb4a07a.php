<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('stisla/js/page/modules-datatables.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-header">
                <h1>Pertanyaan</h1>
                <div class="section-header-breadcrumb">
                    <div class="breadcrumb-item active">
                        <a href="<?php echo e(route('admin.questions.index')); ?>">Pertanyaan</a>
                    </div>
                    <div class="breadcrumb-item">List Pertanyaan</a></div>
                </div>
            </div>

            <div class="section-body">
                <div class="row">
                    <div class="container d-flex justify-items-stretch">
                        <div class="col">
                            <h2 class="section-title mt-0">Pertanyaan</h2>
                            <p class="section-lead">
                                Halaman untuk mengatur data-data pertanyaan.
                            </p>
                        </div>
                        <div class="col">
                            <a href="<?php echo e(route('admin.questions.create')); ?>" class="btn btn-info float-right">Tambah <i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Data Pertanyaan</h4>
                            </div>
                            <div class="card-body">
                                <?php if(session()->has('status')): ?>
                                    <div class="alert alert-<?php echo e(session()->get('status')); ?>" role="alert">
                                        <span class="font-weight-bold"><?php echo e(session()->get('message')); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="container table-responsive">
                                    <table class="table table-striped" id="table-0">
                                        <thead>
                                            <tr>
                                                <th class="text-center">
                                                    No
                                                </th>
                                                <th>Informasi</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="text-center">
                                                        <?php echo e($key+1); ?>

                                                    </td>
                                                    <td>
                                                        <span class="font-weight-bold">Pertanyaan:</span> <?php echo e($datum->question); ?> <br>
                                                        <span class="font-weight-bold">Deskripsi:</span> <?php echo e(strip_tags($datum->description)); ?>

                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('admin.questions.edit', $datum->id)); ?>" class="btn btn-warning mr-2">Edit <i class="fas fa-edit"></i></a>
                                                        <form class="d-inline" action="<?php echo e(route('admin.questions.destroy', $datum->id)); ?>" method="post">
                                                            <?php echo e(method_field('DELETE')); ?>

                                                            <?php echo e(csrf_field()); ?>

                                                            <button class="btn btn-danger" type="submit">Hapus <i class="fas fa-times"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/admin/questions/index.blade.php ENDPATH**/ ?>