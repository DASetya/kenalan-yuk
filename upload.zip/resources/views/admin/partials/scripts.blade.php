<!-- General JS Scripts -->
<script src="{{ asset('js/admin/app.js') }}"></script>
<script src="{{ asset('stisla/js/stisla.js') }}"></script>

<!-- Template JS File -->
<script src="{{ asset('stisla/js/scripts.js') }}"></script>
<script src="{{ asset('stisla/js/custom.js') }}"></script>

<!-- Page Specific JS File -->
@yield('scripts')