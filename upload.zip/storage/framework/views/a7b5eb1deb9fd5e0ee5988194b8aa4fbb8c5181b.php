<!-- General JS Scripts -->
<script src="<?php echo e(asset('js/admin/app.js')); ?>"></script>
<script src="<?php echo e(asset('stisla/js/stisla.js')); ?>"></script>

<!-- Template JS File -->
<script src="<?php echo e(asset('stisla/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('stisla/js/custom.js')); ?>"></script>

<!-- Page Specific JS File -->
<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/admin/partials/scripts.blade.php ENDPATH**/ ?>