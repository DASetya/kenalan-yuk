 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold leading-tight">
            Hi, <?php echo e(auth()->user()->name); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl text-center py-4 my-5 overflow-hidden shadow-xl sm:rounded-lg">
                <h3 class="mb-4">Progress Kisahku</h3>
                <span class="text-primary mb-3 block">0%</span>
                
                <a href="<?php echo e(route('my-story.index')); ?>" class="button button-light">
                    Lanjutkan Pengisian 
                    <i class="fas fa-angle-double-right ml-5"></i>
                </a>
            </div>

            <div class="bg-white rounded-2xl text-center py-4 my-5 overflow-hidden shadow-xl sm:rounded-lg">
                <h3 class="mb-4">Kebahagiaan</h3>
                <p class="text-primary font-semibold">
                    Sepertinya kamu lupa mengisi tingkat kebahagiaanmu pada hari ini!
                </p>
                <p class="text-primary">
                    Beri tahu kami sekarang yuk tingkat kebahagiaan kamu hari ini!
                </p>
                <a href="<?php echo e(route('mood.index')); ?>" class="button button-light">
                    Lanjutkan Pengisian 
                    <i class="fas fa-angle-double-right ml-5"></i>
                </a>
            </div>

            <div class="bg-white rounded-2xl text-center py-4 my-5 overflow-hidden shadow-xl sm:rounded-lg">
                <h3 class="mb-4">Syukur</h3>
                <p class="text-primary">Kamu belum mengisi rasa syukur pada hari ini!</p>
                <a href="<?php echo e(route('syukur.index')); ?>" class="button button-light">
                    Lanjutkan Pengisian 
                    <i class="fas fa-angle-double-right ml-5"></i>
                </a>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/dashboard.blade.php ENDPATH**/ ?>