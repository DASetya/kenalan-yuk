<div class="bg-white rounded-2xl grid grid-cols-3 gap-5 overflow-hidden shadow-md sm:rounded-lg my-5 p-3">
    <div class="col-start-2 text-center my-auto">
        <h2 class="text-primary font-bold">
            Kisahku
            <button wire:click="$toggle('showModalAdd')" class="float-right"><i class="fas fa-plus"></i></button>
        </h2>
    </div>
    
    <div>
         <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.modal','data' => ['id' => 'modalAddMood','wire:model' => 'showModalAdd']]); ?>
<?php $component->withName('jet-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('modalAddMood'),'wire:model' => 'showModalAdd']); ?>
            <form wire:submit.prevent="store">
                <div class="px-6 py-4">
                    <div class="text-lg text-bold">
                        Tulis Kisahku
                    </div>

                    <div class="mt-4">
                        <div class="grid">
                            <select name="category" wire:model="category" class="bg-white border p-3 shadow-sm w-2/3 mx-auto rounded-lg">
                                <option>Pilih Tema Kisah</option>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($datum->id); ?>">
                                        <?php echo e($datum->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'category','class' => 'mx-auto']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'category','class' => 'mx-auto']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

                            <div class="py-2"></div>

                            <textarea wire:model="story" rows="5" placeholder="Inilah kisahku" class="border p-3 shadow-sm w-2/3 mx-auto rounded-lg"></textarea>
                             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'story','class' => 'mx-auto']]); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'story','class' => 'mx-auto']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                </div>
            
                <div class="px-6 py-4 bg-gray-100 text-right">
                    <button type="submit" class="button button-success mr-3">Tambah <i class="fas fa-plus"></i></button>
                    <button wire:click="$toggle('showModalAdd')" class="button" type="button">Tutup <i class="fas fa-times"></i></button>
                </div>
            </form>
         <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </div>
</div><?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/my-story/create.blade.php ENDPATH**/ ?>