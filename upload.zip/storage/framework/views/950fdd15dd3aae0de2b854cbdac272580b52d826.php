<div>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div
            wire:click="$emitTo('my-story.edit', 'showModal', <?php echo e($datum->id); ?>)" 
            class="bg-white rounded-2xl cursor-pointer grid overflow-hidden shadow-md sm:rounded-lg my-5 p-3"
        >
            <div class="text-center my-auto">
                <h3 class="text-xl font-bold"><?php echo e($datum->myStoryCategory->name); ?></h3>
                <span><?php echo e($datum->story); ?></span>
            </div>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-story.edit', ['myStoryId' => $datum->id])->html();
} elseif ($_instance->childHasBeenRendered('listMyStory-' . $datum->id)) {
    $componentId = $_instance->getRenderedChildComponentId('listMyStory-' . $datum->id);
    $componentTag = $_instance->getRenderedChildComponentTagName('listMyStory-' . $datum->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('listMyStory-' . $datum->id);
} else {
    $response = \Livewire\Livewire::mount('my-story.edit', ['myStoryId' => $datum->id]);
    $html = $response->html();
    $_instance->logRenderedChild('listMyStory-' . $datum->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/my-story/list-my-story.blade.php ENDPATH**/ ?>