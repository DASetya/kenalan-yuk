 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Syukur
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container mx-auto sm:px-6 lg:px-8">
            <div class="bg-white grid grid-cols-3 gap-5 overflow-hidden shadow-md sm:rounded-lg my-5 p-3">
                <div class="col-start-2 text-center my-auto">
                    <span class="font-bold">Gratitude Journal</span>
                </div>
                
                <div>
                    <a href="#" class="button button-primary float-right"><i class="fas fa-question"></i></a>
                    <button href="#" class="button button-primary float-right mr-3">Tambah <i class="fas fa-plus"></i></button>
                     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.modal','data' => ['maxWidth' => 500]]); ?>
<?php $component->withName('jet-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['maxWidth' => 500]); ?>
                        <div class="px-6 py-4">
                            <div class="text-lg">
                                ini judul
                            </div>
                    
                            <div class="mt-4">
                                Konten
                            </div>
                        </div>
                    
                        <div class="px-6 py-4 bg-gray-100 text-right">
                            ini footer
                        </div>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('syukur.index')->html();
} elseif ($_instance->childHasBeenRendered('qAdzL1Q')) {
    $componentId = $_instance->getRenderedChildComponentId('qAdzL1Q');
    $componentTag = $_instance->getRenderedChildComponentTagName('qAdzL1Q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qAdzL1Q');
} else {
    $response = \Livewire\Livewire::mount('syukur.index');
    $html = $response->html();
    $_instance->logRenderedChild('qAdzL1Q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/syukur/index.blade.php ENDPATH**/ ?>