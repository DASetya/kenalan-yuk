<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2018 <div class="bullet"></div> Design By <a href="https://nauval.in/">Muhamad
            Nauval Azhar</a>
    </div>
    <div class="footer-right">
        2.3.0
    </div>
</footer><?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/admin/partials/footer.blade.php ENDPATH**/ ?>