<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(route('admin.questions.index')); ?>">Kenalan Yuk</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(route('admin.questions.index')); ?>">St</a>
        </div>
        <ul class="sidebar-menu">
            
            <li class="menu-header">
                Data Master
            </li>

            <li class="<?php echo e((request()->routeIs('admin.questions.*')) ? 'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.questions.index')); ?>">
                    <i class="far fa-square"></i>
                    <span>Pertanyaan</span>
                </a>
            </li>

            <li class="<?php echo e((request()->routeIs('admin.my-story-categories.*')) ? 'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.my-story-categories.index')); ?>">
                    <i class="far fa-square"></i>
                    <span>Kategori Kisahku</span>
                </a>
            </li>

            <li class="<?php echo e((request()->routeIs('admin.psychologists.*')) ? 'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin.psychologists.index')); ?>">
                    <i class="far fa-square"></i>
                    <span>Psikolog</span>
                </a>
            </li>

        </ul>

        <div class="mt-4 mb-4 p-3 hide-sidebar-mini">
            <a href="<?php echo e(route('index')); ?>" target="_blank" class="btn btn-primary btn-lg btn-block btn-icon-split">
                <i class="fas fa-rocket"></i> Cek Website
            </a>
        </div>
    </aside>
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/admin/partials/sidebar.blade.php ENDPATH**/ ?>