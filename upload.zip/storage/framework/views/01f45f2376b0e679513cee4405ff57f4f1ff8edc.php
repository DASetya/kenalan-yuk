<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Kenalan Yuk</title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/addon.css')); ?>">

        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.0/dist/alpine.js" defer></script>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-primary-gradient">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-dropdown')->html();
} elseif ($_instance->childHasBeenRendered('d84vW8d')) {
    $componentId = $_instance->getRenderedChildComponentId('d84vW8d');
    $componentTag = $_instance->getRenderedChildComponentTagName('d84vW8d');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('d84vW8d');
} else {
    $response = \Livewire\Livewire::mount('navigation-dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('d84vW8d', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Heading -->
            <header class="header bg-white shadow">
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </header>

            <!-- Page Content -->
            <main class="pb-8 px-4 rounded-lg">
                <?php echo e($slot); ?>

            </main>

            <footer class="hidden xs:flex fixed min-w-full bottom-0 footer">
                <div class="my-4">
                    <a href="<?php echo e(route('dashboard')); ?>" class="px-4 align-middle">
                        <i class="fas fa-home"></i>
                    </a>

                    <a href="<?php echo e(route('syukur.index')); ?>" class="px-4 align-middle">
                        <i class="fas fa-praying-hands"></i>
                    </a>

                    <a href="<?php echo e(route('mood.index')); ?>" class="px-4 align-middle">
                        <i class="fas fa-grin"></i>
                    </a>

                    <a href="<?php echo e(route('my-story.index')); ?>" class="px-4 align-middle">
                        <i class="fas fa-book"></i>
                    </a>

                    <a href="<?php echo e(route('psychologist.index')); ?>" class="px-4 align-middle">
                        <i class="fas fa-user"></i>
                    </a>
                </div>
            </footer>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>


        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/layouts/app.blade.php ENDPATH**/ ?>