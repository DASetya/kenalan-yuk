<div>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold leading-tight">
            Kisahku
            <a href="#" class="text-2xl"><i class="far fa-question-circle"></i></a>
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="container mx-auto sm:px-6 lg:px-8">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-story.create', [])->html();
} elseif ($_instance->childHasBeenRendered('qEMFvQh')) {
    $componentId = $_instance->getRenderedChildComponentId('qEMFvQh');
    $componentTag = $_instance->getRenderedChildComponentTagName('qEMFvQh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qEMFvQh');
} else {
    $response = \Livewire\Livewire::mount('my-story.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('qEMFvQh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-story.list-my-story', [])->html();
} elseif ($_instance->childHasBeenRendered('wnzsdP8')) {
    $componentId = $_instance->getRenderedChildComponentId('wnzsdP8');
    $componentTag = $_instance->getRenderedChildComponentTagName('wnzsdP8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wnzsdP8');
} else {
    $response = \Livewire\Livewire::mount('my-story.list-my-story', []);
    $html = $response->html();
    $_instance->logRenderedChild('wnzsdP8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php /**PATH /home/fattach/Projects/Web/kenalan-yuk/resources/views/livewire/my-story/index.blade.php ENDPATH**/ ?>